function [cplex, time] = cplex_LR_mimo(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,Pmax)
% Solve the linear relaxation of QCQP over [tlb,tub]
% min  x'*H*x + f'*x - \sum_{i=1}^{nr} s_i
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub,
%      s_i <= (tl(i)+tu(i))*(c_i^T x)-tl(i)*tu(i)
%      tlb(i) <= c_i^T x <= tub(i), i=1,...,nr.
%
tstart = tic;
[nx,nr] = size(c);
cplex = Cplex();
cplex.DisplayFunc = [];
cplex.Param.timelimit.Cur = 1800;
cplex.Param.threads.Cur = 1;
cplex.Param.qpmethod.Cur = 1;
% 0 = automatic, 1 = primal simplex, 2 = dual simplex, 3 = network simplex,
% 4 = barrier, 5 = sifting, 6 = concurrent optimizers
cplex.Param.emphasis.memory.Cur = 0;            % reduce use of memory;
cplex.Model.sense = 'minimize';
% lower and upper bound constraints
% x,s
cplex.addCols([f;-ones(nr,1)],[],[xlb;zeros(nr,1)],[xub;inf*ones(nr,1)]);
lambda = sum(c.*c,1);
cplex.addRows(-inf,[zeros(1,nx),1./lambda],Pmax);  % cut
if ~isempty(Aeq)
    nAeq = size(Aeq,1);
    cplex.addRows(beq,[Aeq sparse(nAeq,nr)],beq);
end
if ~isempty(Aineq)
    nAineq = size(Aineq,1);
    cplex.addRows(-inf*ones(nAineq,1),[Aineq sparse(nAineq,nr)],bineq);
end
cplex.addRows(-inf*ones(nr,1),[sparse(nr,nx),speye(nr)],ones(nr,1));
cplex.addRows(-inf*ones(nr+nr,1),[c' sparse(nr,nr); -c' sparse(nr,nr)],ones(nr+nr,1));
for iQC = 1:size(Q,2)
    cplex.addQCs([q(:,iQC);sparse(nr,1)],[Q{iQC} sparse(nx,nr);sparse(nr,nx+nr)],'L',r(iQC));
end
if ~isempty(H)        
    cplex.Model.Q = [H+H' sparse(nx,nr);sparse(nr,nx+nr)];
end
time = toc(tstart);
end