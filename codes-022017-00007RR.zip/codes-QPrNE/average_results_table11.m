function average_results_table11()
%average_results_rank1()
clc;
err = 1.0e-6;
allqc = [0 1 3 5];          % number of quadratic constraints 
allnr = [1 2 3 4 5 8 10];   % number of negative eigenvalue

for inr = 1:1
    nr = allnr(inr);
for iqc = 1:1
    nQC = allqc(iqc);    
for iloop = 1:1:10
    nx = iloop*500;           % the number of variables
    nLC = round(nx/5);       % the number of linear constraints      
%     nLC = 0;
    
    filename = sprintf('results\\rank1_results_%d_%d_%d.txt',nQC,nLC,nx);
%     fprintf(1,'%s\n',filename);
%     fid = fopen(filename,'at+');
    
    alldata = load(filename);
    
    index = alldata(:,6)>3600; %BB
%     alldata(:,14)>3600
    x1 = alldata(:,1:4);
    x2 = alldata(:,5:12);
    x2 = x2(~index,:);
    x3 = alldata(:,13:21);
        
    x1 = sum(x1,1)/size(x1,1);
    x2 = sum(x2,1)/size(x2,1);
    x3 = sum(x3,1)/size(x3,1);
    
    x=[x1 x2 x3];
    
    
    
    
%     size(alldata)
%     x = sum(alldata,1)/size(alldata,1);
%     size(x)
    i=1;
% 
%     fprintf(1,'%2d & ',x(i,2));   %nQC
    fprintf(1,'%4d & ',x(i,3));    %nLC
    fprintf(1,'%4d & ',x(i,4));    %nx
%     fprintf(1,'%2d & ',x(i,5));    %nr 
    % BB
    if nx<4000
        fprintf(1,'%10.4f & %7.2f & %4d & ',x(i,5),x(i,6),round(x(i,8))); % val,time,iter
        fprintf(1,'%10.4f & ',x(i,11)); % val_adm
        fprintf(1,'%2d  & ',round(x(i,9))); % T_adm
    else
        fprintf(1,'   --      &    --   &   -- & '); % val,time,iter
        fprintf(1,'   --      & '); % val_adm
        fprintf(1,' -- & '); % T_adm
    end
    
    % gsa
    fprintf(1,'%10.4f & %7.2f & %2d & ',x(i,13),x(i,14),round(x(i,15))); % val,time,iter
    fprintf(1,'%7.2f & ',x(i,21)); % t_lsa
    fprintf(1,'%2d & %7.2f & ',round(x(i,16)),x(i,18)); % iter,t_adm
    
    % KKT-SDP
%     fprintf(1,'%10.4f & %7.2f & ',x(i,23),x(i,24)); % val,time
    
    fprintf(1,'\\\\ \n');

end
end
end