% function [x,fval,time,iter,f1,t1] = solve_qcqp_gsa(filename)
% load(filename);
function [x_opt,v_opt,time,info] = solve_qcqp_baron(H,f,c,Aineq,bineq,Aeq,beq,Q,q,r,xlb,xub,err)
% solving the following problem using BARON
% min  x'*H*x+f'*x-(c'*x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub.
%
MaxIter = 100000;
MaxTime = 3600;
oldopts = baronset();
oldopts = baronset(oldopts,'MaxTime',MaxTime,'MaxIter',MaxIter,'EpsR',err);
% the cplex path should be changed according to the computer settings
oldopts = baronset(oldopts,'cplexlibname','D:\Program Files\IBM\ILOG\CPLEX_Studio1263\cplex\matlab\x64_win64\cplex1263.dll');
opts = baronset(oldopts,'LPSol',8);

%%
fprintf(1,'========= Solving by BARON =========\n');
tstart = tic;

%%
%Objective
% fun = @(x) x'*H*x+f'*x-(norm(c'*x))^2;
fun = @(x) faux(x,[],H,f,c);

%Linear Constraints
A = [Aeq;Aineq];
rl = [beq;-inf*ones(size(bineq))];
ru = [beq;bineq];   

%Nonlinear Constraints
fnlcon = @(x) nlcon(x,Q,q);

%Solve
if size(Q,2) == 0 % no quadratic constraints
    [x_opt,v_opt,~,info] = baron(fun,A,rl,ru,xlb,xub,[],[],[],[],[],opts);
else
    [x_opt,v_opt,~,info] = baron(fun,A,rl,ru,xlb,xub,fnlcon,-inf*ones(size(r')),r',[],[],opts);
end

time = toc(tstart);
fprintf(1,'fval = %.6f, time = %6.2f, iter = %3d \n',v_opt,time,info.BaR_Iterations);
end