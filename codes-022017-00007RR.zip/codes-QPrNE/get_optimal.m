function [x,fval] = get_optimal(H,f,c,Q,q,r,Aeq,beq,Aineq,bineq,xlb,xub,t0)
% solving the following convex problem
% min  x'*H*x+f'*x-t^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      c'*x = t,
%      xlb <= x <= xub.
% where t is given
%
try    
    Aeq0 = [Aeq;
        c'];  % c'*x=t
    beq0 = [beq;t0];    
    %
    cplex = Cplex();
    cplex.DisplayFunc = [];
    cplex.Model.sense = 'minimize';
    % lower and upper bound constraints
    cplex.addCols(f,[],xlb,xub);
    cplex.addRows(beq0,Aeq0,beq0);
    if ~isempty(Aineq)
        cplex.addRows(-inf*ones(size(bineq)),Aineq,bineq);
    end
    for iQC = 1:size(Q,2)
        cplex.addQCs(q(:,iQC),Q{iQC},'L',r(iQC));
    end    
    if ~isempty(H)
        cplex.Model.Q = H+H';
    end
    cplex.solve();
    x = cplex.Solution.x;
%     fval = cplex.Solution.objval-(c'*x)^2;
    if ~isempty(H)
        fval = x'*H*x+f'*x-(c'*x)^2;
    else % for clique problem
        fval = f'*x-(c'*x)^2;
    end
%     fprintf(1,'\nSolution.status = %d\n',cplex.Solution.status);
%     fprintf(1,'Solution.status = %s\n',cplex.Solution.statusstring);  
%     fprintf(1,'The size of the linear constraints:');
%     fprintf(1,'    %d * %d\n',size(cplex.Model.A,1),size(cplex.Model.A,2));
%     fprintf(1,'The size of the quadratic constraints:');
%     fprintf(1,' %d\n',size(cplex.Model.qc,1));
catch err
    rethrow(err);    
end
end