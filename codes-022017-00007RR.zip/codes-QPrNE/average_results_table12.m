function average_results_table12()
clc;
err = 1.0e-6;
allqc = [0 1 3 5];   % number of quadratic constraints 
allnr = [1 2 3 4 5 8 10];            % number of negative eigenvalue

for inr = 1:1
    nr = allnr(inr);
for iqc = 1:4
    nQC = allqc(iqc);    
for iloop = 1:1:5
    nx = iloop*5;           % the number of variables
%     nLC = round(nx/5);       % the number of linear constraints      
    nLC = 10;
    filename = sprintf('results\\qcqp_results_%d_%d_%d_%d.txt',nQC,nLC,nx,nr);
%     fprintf(1,'%s\n',filename);
    if  nQC>=3 && nx == 25        
        continue;
    end
%     fid = fopen(filename,'at+');
    
    alldata = load(filename); 
    alldata = alldata(1:5,:);
    
    index = alldata(:,7)>3600; %BB
    index1 = alldata(:,24)>3600;  
    index3 = alldata(:,28)>3600;
    
    x1 = alldata(:,1:5);
    x2 = alldata(:,6:13);
    x2 = x2(~index,:);
    x3 = alldata(:,14:22);
    x4 = alldata(:,23:26);
    x4 = x4(~index1,:);
    x5 = alldata(:,27:29);
    
    x1 = sum(x1,1)/size(x1,1);
    x2 = sum(x2,1)/size(x2,1);
    x3 = sum(x3,1)/size(x3,1);
    x4 = sum(x4,1)/size(x4,1);
    x5 = sum(x5,1)/size(x5,1);
    
    x=[x1 x2 x3 x4 x5];
    
%     size(alldata)
%     x = sum(alldata,1)/size(alldata,1);
%     size(x)
    i=1;
% 
    fprintf(1,'%2d & ',x(i,2));   %nQC
    fprintf(1,'%3d & ',x(i,3));   %nLC
    fprintf(1,'%4d & ',x(i,4));   %nx    
    %fprintf(1,'%2d & ',x(i,5));   %nr  
    % BB
    fprintf(1,'%10.4f & %7.2f & ',x(i,6),x(i,7)); % val,time,iter 
%     fprintf(1,'%4d & ',round(x(i,9))); % val,time,iter
%     fprintf(1,'%10.4f & ',x(i,12)); % val_adm
%     fprintf(1,'%2d & ',round(x(i,10))); % T_adm
    
    % gsa
    fprintf(1,'%10.4f & %7.2f & %d & ',x(i,14),x(i,15)); % val,time,iter
%     fprintf(1,'%d & ',round(x(i,16))); % val,time,iter
%     fprintf(1,'%3d & ',round(x(i,22))); % T_lsa
%     fprintf(1,'%3d & %7.2f & ',round(x(i,17)),x(i,19)); % iter_adm,T_adm
    
    % KKT-SDP
%     fprintf(1,'%10.4f(%d) & %7.2f & ',x(i,23),nnz(index1),x(i,24)); % val,time
    
    %
    fprintf(1,'%10.4f(%d) & %7.2f & ',x(i,27),nnz(index3),x(i,28)); % val,time
%      fprintf(1,'%d & ',round(x(i,29))); % val,time
    fprintf(1,'\\\\ \n');

end
fprintf(1,'\\hline \n');
end

end