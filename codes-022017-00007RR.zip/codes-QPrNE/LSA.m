function [delta,x_opt,t_opt,gb,v,iter,time] = LSA(H,f,c,t0,delta0,gb0,x0,lsa,eps)
%
%
% 
MaxIter = 100;
MaxTime = 1800;
nx = length(c);
gb = gb0;
x_opt = x0;
t_opt = c'*x_opt;
delta = delta0;
v = [];
% x,s,t
% cplex = Cplex();
% cplex.DisplayFunc = [];
% cplex.Param = lsa.Param;
% cplex.Model = lsa.Model;
cplex = lsa;

%%
iter = 0;
tstart = tic;
while iter < MaxIter && toc(tstart) < MaxTime 
    iter = iter+1;    
    tlb = min(t0,t0+delta);
    tub = max(t0,t0+delta);    
    cplex.Model.lb(end) = tlb;
    cplex.Model.ub(end) = tub;    
    cplex.Model.A(end,end) = -(tlb+tub);
    cplex.Model.rhs(end) = -(tlb*tub);    
    cplex.solve();
    if cplex.Solution.status ~= 1
        fprintf(2,'\nExist in LSA:');
        fprintf(2,'time = %.f,  ',cplex.Solution.time);
        fprintf(2,'status = %d: ',cplex.Solution.status);
        fprintf(2,'%s\n',cplex.Solution.statusstring);
        delta = 0;        
        return;
    end
    x = cplex.Solution.x(1:nx);
%     s = cplex.Solution.x(nx+1);
%     t = cplex.Solution.x(end);
    v = cplex.Solution.objval;
%     fprintf(1,'t=%10.f,%10.f,%10.f\n',t,tlb,tub);
    gb1 = faux(x,[],H,f,c);
    if gb1<gb
        gb = gb1;
        x_opt = x;
        t_opt = c'*x_opt;
    end        
    fprintf(1,'LSA: iter=%3d,gb=%.6f,glb=%.6f,gb0=%.6f,delta=%.6f\n',iter,gb,v,gb0,delta);
    if v >= (gb-eps) || v >= (gb1-eps)
        break;
    else
        delta = delta/2;
    end
end
time = toc(tstart);
end