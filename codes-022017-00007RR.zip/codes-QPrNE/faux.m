function fval = faux(x,t,H,f,c)
nx = length(x);
if isempty(H)
    H = sparse(nx,nx);        
end
if ~isempty(t)
    fval = x'*H*x+f'*x-norm(t)^2;   
else
    fval = x'*H*x+f'*x-(norm(c'*x))^2;
end
end