function [x,v,time] = LSA0(H,f,c,t0,delta0,lsa)
%
%
% 
nx = length(c);
delta = delta0;
v = [];
x = [];
% x,s,t
% cplex = Cplex();
% cplex.DisplayFunc = [];
% cplex.Param = lsa.Param;
% cplex.Model = lsa.Model;
cplex = lsa;

%%
tstart = tic;
tlb = min(t0,t0+delta);
tub = max(t0,t0+delta);
cplex.Model.lb(end) = tlb;
cplex.Model.ub(end) = tub;
cplex.Model.A(end,end) = -(tlb+tub);
cplex.Model.rhs(end) = -(tlb*tub);
cplex.solve();
if cplex.Solution.status ~= 1
    fprintf(2,'\nExist in LSA0:');
    fprintf(2,'time = %.f,  ',cplex.Solution.time);
    fprintf(2,'status = %d: ',cplex.Solution.status);
    fprintf(2,'%s\n',cplex.Solution.statusstring);
    return;
end
x = cplex.Solution.x(1:nx);
% s = cplex.Solution.x(nx+1);
% t = cplex.Solution.x(end);
v = cplex.Solution.objval;
% fprintf(1,'t=%10.f,%10.f,%10.f\n',t,tlb,tub);
time = toc(tstart);
end