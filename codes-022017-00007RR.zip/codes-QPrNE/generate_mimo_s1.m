function [A,Q,r] = generate_mimo_s1(nM,nN,nK)
% max  t^H A t
% s.t. t^H Q t <= 1, i=1,...,m
%      t^H t<= P_{s,max}
% where A,Q is Hermitian Complex Matrix
% P is max power
%
% rand('state',10);
% randn('state',10);
% rng(0,'twister');


%%
nK1 = nK+1;
N0 = 0.05;
% generate the data
% objective
d = 5*rand(nK1,nK1)+10; %[10,15]
d(nK1,nK1) = 10;
alpha = 1./(d.^4); % {k,k}
H = cell(nK1,nK1);
for iki = 1:nK1
    for ikj=1:nK1
        H{iki,ikj} = randn(nN,nM) + 1i * randn(nN,nM);
    end
end
Phi = zeros(nN,nN);
tk = zeros(nM,nK);
for ik = 1:nK
    [~,~,V] = svd(H{ik,ik});
    tk(:,ik) = V(:,1);    
%     size(tk(:,ik))
%     size(H{nK1,ik})
%     alpha(nK1,ik)
    Phi = Phi+alpha(nK1,ik)*(H{nK1,ik}*(tk(:,ik)*tk(:,ik)')*H{nK1,ik}');
end
Phi = Phi+N0*(eye(nN) + 1i*zeros(nN));  % N_0=0.05
A = alpha(nK1,nK1) * H{nK1,nK1}'*(Phi\H{nK1,nK1});
A = ((real(A)+real(A)') + 1i* (imag(A)-imag(A)'))/2;
% H0 = -[real(A) -imag(A);imag(A) real(A)];
% H0 = (H0+H0')/2;
% fprintf(1,'%.7f\n',eig(H0));

% quadratic constraints
Q = cell(1,nK1);
r = ones(1,nK1);
for ik = 1:nK
    H_hat = zeros(nN,nN);
    for ii=1:nK
        H_hat(:,ii) = sqrt(alpha(ik,ii))*(H{ik,ii}*tk(:,ii));
    end
    rk = H_hat(:,ik);
    H_hat(:,ik) = [];
    HH = H_hat*H_hat';    
    WW = ((real(HH)+real(HH)') + 1i* (imag(HH)-imag(HH)'))/2 + N0*(eye(nN) + 1i*zeros(nN));
    rk = WW\rk;
    rk = rk/norm(rk);
    
    Q{ik} = alpha(ik,nK1)*(H{ik,nK1}'*(rk*rk')*H{ik,nK1});
    Q{ik} = ((real(Q{ik})+real(Q{ik})') + 1i* (imag(Q{ik})-imag(Q{ik})'))/2; 
%     H0 = [real(Q{ik}) -imag(Q{ik});imag(Q{ik}) real(Q{ik})];
%     H0 = (H0+H0')/2;
%     eig(H0)
%     pause
end
Q{nK1} = eye(nM) + 1i*zeros(nM);
r(nK1) = 10/(alpha(nK1,nK1)^2)*1.0e-8;



