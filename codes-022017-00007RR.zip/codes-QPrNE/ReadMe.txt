The codes are used to test the methods presented in "New Global Algorithms for Quadratic Programming with A Few Negative Eigenvalues Based on Alternative Direction Method and Convex Relaxation" , which has been submitted to Mathematical Programming Computation.

The codes are organized as follows


The key parameters in the codes include:
  nQC  --    the number of quadratic constraints
  
  nLC  --    the number of linear constraints
  
  nr   --    the number of negative eigenvalues
  
  nx   --    the number of variables
  
  nex  --    the number of numerical examples


The program will generate different size of problem by setting the parameters as different values.


"test_01qp.m" is used to test "the concave 0-1 quadratic program", which is presented in 5.1.1.
You can run the codes directly, and it will generate the data automatically according the method presented in Subsection 5.1.3.

"test_qcqp_rand.m" is used to test general quadratic constrained quadratic program, including ""5.1.2. 5.1.3 5.2.3
You can run the codes directly, and it will generate the data automatically according the method presented in Subsection 5.1.3.


"test_clique.m" is used to test "the Clique problem" presented in 5.2.1.
You can run the codes directly, and it will load the data and generate the figuer automatically.
Also, the computaion result will be displayed in Command Window.

"test_qcqp_rank1.m" is used to test "The rank-one nonconvex quadratic program", which is presented in 5.2.2.
You can run the codes directly, and it will generate the data automatically according the method presented in Subsection 5.1.3.


To run the code successfully, MATLAB, BARON and CPLEX should be installed in advance.
Beyond that, the path of the interface of Cplex for Matlab should be added to the search path of Matlab.

The correct path which should be changed has been marked in the codes. 
See ``test_01qp.m", ``test_qcqp_rand.m",
``test_clique.m", ``test_qcqp_rank1.m" and ``solve_qcqp_baron.m" for more details.

For example, if you want to obtain the average results of 5 examples, which has 100 variables and 10 linear constraints, for ``The rank-one nonconvex quadratic program",  you can do it as follows

-- Set nx=100, nLC = 10, nex=5 in the file ``test_qcqp_rank1.m"
  
-- Run ``test_qcqp_rank1()" in the Command Window.
  
-- The code will generate the data and compute the problem automatically. The computing results will be saved in the file ``...\results\rank1_results_nQC_nLC_nx.txt"
  
-- Run ``average_results_rank1().m" to get the average results. The average results will be displayed in LaTex format.

