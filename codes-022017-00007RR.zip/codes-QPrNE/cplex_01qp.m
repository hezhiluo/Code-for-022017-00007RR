function [x,fval,time,gap,iter] = cplex_01qp(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub)
% Solve the 0-1 QP
% min  x'*H*x + f'*x - (c'*x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub,
%      x_i \in {0,1}
%
tstart = tic;
[nx,~] = size(c);
cc = c*c';
cc = (cc+cc')/2;
% cvx_begin sdp quiet
%     variable rho(nx,1)
%     minimize (ones(nx,1)'*rho)
%     subject to
%         diag(rho) - cc <In> semidefinite(nx);
%         rho >= 0;
% cvx_end
% d = eig(cc);
% rho = max(d)*ones(nx,1);
rho = zeros(nx,1);

%
ctype = char(66*ones(1,nx)); % B
cplex = Cplex();
cplex.DisplayFunc = [];
cplex.Param.timelimit.Cur = 3600;
cplex.Param.emphasis.memory.Cur = 0;            % reduce use of memory;
cplex.Model.sense = 'minimize';
% lower and upper bound constraints
cplex.addCols(f-rho,[],xlb,xub,ctype);
if ~isempty(Aeq)
    cplex.addRows(beq, Aeq, beq);
end
if ~isempty(Aineq)
    cplex.addRows(-inf*ones(size(Aineq,1),1), Aineq ,bineq);
end
for iQC = 1:size(Q,2)
    cplex.addQCs(q(:,iQC),Q{iQC},'L',r(iQC));
end
if ~isempty(H)        
    cplex.Model.Q = (H+H')+(diag(rho)-cc)+(diag(rho)-cc)';
else    
    cplex.Model.Q = (diag(rho)-cc)+(diag(rho)-cc)';
end
cplex.solve();
if cplex.Solution.status ~= 101    
    fprintf(2,'Solution.time = %.f,  ',cplex.Solution.time);
    fprintf(2,'Solution.status = %d: ',cplex.Solution.status);
    fprintf(2,'%s\n',cplex.Solution.statusstring);    
end
x = cplex.Solution.x;
fval = cplex.Solution.objval;
gap = cplex.Solution.miprelgap*100;
if isfield(cplex.Solution,'mipitcnt')==1
    iter = cplex.Solution.mipitcnt;
else
    iter = 0;
end
time = toc(tstart);
end