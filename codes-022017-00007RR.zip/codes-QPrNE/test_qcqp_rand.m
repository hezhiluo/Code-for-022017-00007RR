function test_qcqp_rand()
% solving the following general qcqp
% min  x'*H*x+f'*x-\sum_{i=1}^{nr} (c_i'*x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub.
%
clear
clc
% addpath('D:\Program Files\IBM\ILOG\CPLEX_Studio1263\cplex\matlab\x64_win64');
% rand('state',10);
% randn('state',10);
% rng(0,'twister');
err = 1.0e-6;
allqc = [0 1 3 5];          % number of quadratic constraints 
allnr = [1 2 3 4 5 8 10];   % number of negative eigenvalue
nex = 5;        % the number of the numerical examples
try
for inr = 2:5
    nr = allnr(inr);
for iqc = 2:4
    nQC = allqc(iqc); 
    
    switch nr
        case 2; 
            switch nQC
                case 1; nxx = [4,5,6,7,8,9,10];
                case 3; nxx = [4,5,6,7,8,9,10];
                case 5; nxx = [4,5,6,7];
            end
        case 3; 
            switch nQC
                case 1; nxx = [4,5,6,7,8,9,10];
                case 3; nxx = [4,5,6,7];
                case 5; nxx = [3,4,5];
            end
        case 4;
            switch nQC
                case 1; nxx = [2,3,4,5,6,7,8,9];
                case 3; nxx = [2,3,4,5,6];
                case 5; nxx = [2,3,4];
            end
        case 5; 
            switch nQC
                case 1; nxx = [2,3,4,5,6,7];
                case 3; nxx = [2,3,4,5];
                case 5; nxx = [1,2,3];
            end
        otherwise;    break;
    end
    
for iloop = nxx
    nx = iloop*100;           % the number of variables
    nLC = round(nx/5);       % the number of linear constraints      
%     nLC = 0;
    
    filename = sprintf('results\\qcqp_results_%d_%d_%d_%d.txt',nQC,nLC,nx,nr);
%     if  nQC==3  && nx>500
%         continue;
%     end
    fid = fopen(filename,'at+');
    
    jloop = 0;
    while jloop < nex
        jloop = jloop+1;  
        % generate the data
        x0 = rand(nx,1);   %[0,1]
        w = 2*rand(nx,3)-1;  % [-1,1]
        W = cell(3,1);
        for i3=1:3
            W{i3} = eye(nx)-(2*w(:,i3))*w(:,i3)'/norm(w(:,i3))^2;
        end
        P = W{1}*W{2}*W{3};
        d = 1*rand(nx,1);      %[0,1]
        index = randperm(nx);        
        index = index(1:nr);    % nr is the number of negative eigenvalue
        d(index) = -d(index);
        H0 = P*diag(d)*P';      % indefinite
        H0 = (H0+H0')/2;
        [V,D] = eig(H0);
        index = diag(D) >= 1.0e-8;
        H = V(:,index)*D(index,index)*V(:,index)';  % positive definite
        H = (H+H')/2+1.0e-8*eye(nx);        
        f = 2*rand(nx,1)-1;    % U[-1,1]        
        c = V(:,1:nr)*sqrt(-D(1:nr,1:nr));

        % quadratic constraints
        Q = cell(1,nQC);
        q = zeros(nx,nQC);
        r = zeros(1,nQC);
        W = cell(3,1);
        for iQC = 1:nQC
            w = 2*rand(nx,3)-1;  % [-1,1]
            for i3=1:3
                W{i3} = eye(nx)-(2*w(:,i3))*w(:,i3)'/norm(w(:,i3))^2;
            end
            P = W{1}*W{2}*W{3};
            Q{iQC} = P*diag(5*rand(nx,1))*P';   % positive definite
            Q{iQC} = (Q{iQC}+Q{iQC}')/2;
            q(:,iQC) = 10*rand(nx,1);   % [0,10]
            r(iQC) = x0'*Q{iQC}*x0 + x0'*q(:,iQC) + rand;
        end
        % Ax<=b
        Aineq = 10*rand(nLC,nx)-5;       % [-5,5]
        % bineq = 10*rand(nLC,1)+max(A*x_ini,[],2);    %
        bineq = 0.5*sum(max(0,Aineq),2) + rand(nLC,1);  
        if max(Aineq*x0-bineq)>=0
            jloop = jloop-1;
            continue;
        end
        Aeq = [];
        beq = [];
        xlb = zeros(nx,1);
        xub =  ones(nx,1);     
        
%         cplexqcp([], c(:,1),Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub)
        
        %        
        fprintf(1,'nQC = %d, nLC = %d, nx = %d, nr = %d, jloop = %d\n',nQC,nLC,nx,nr,jloop);
%       continue;
       %%    

        fprintf(fid,'%3d  %3d  %3d  %3d  %3d  ',jloop,nQC,nLC,nx,nr);
        if nx <= 4000
            [~,v_opt,time,gap,iter,iter_nadm,time_nadm,v0,t0] =...
                globalsol_qcqp_lr(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,err,1);
            fprintf(1,'iter = %3d ,fval = %.6f,  time = %6.2f\n',iter,v_opt,time);
            fprintf(fid,'%12.8f %7.2f %7.2f %3d   ',v_opt,time,gap,iter);
            fprintf(fid,'%3d  %7.2f   %12.8f %7.2f   ',iter_nadm,time_nadm,v0,t0);
            clear functions
        else
            fprintf(fid,'%12.8f %7.2f %7.2f %3d   ',0,0,0,0);
            fprintf(fid,'%3d  %7.2f   %12.8f %7.2f   ',0,0,0,0);
        end
        
        if nr == 1
            [~,fval,time,iter,iter_nadm,iter_nadm1,time_nadm,iter_lsa,iter_lsa1,time_lsa]...
                = solve_qcqp_gsa(H,f,c,Q,q,r,Aeq,beq,Aineq,bineq,xlb,xub,err);
            fprintf(fid,'%12.8f %7.2f %3d   ',fval,time,iter);
            fprintf(fid,'%3d  %3d  %7.2f   ',iter_nadm,iter_nadm1,time_nadm);
            fprintf(fid,'%3d  %3d  %7.2f   ',iter_lsa,iter_lsa1,time_lsa);            
            clear functions
        else
            fprintf(fid,'%12.8f %7.2f %3d   ',0,0,0);
            fprintf(fid,'%3d  %3d  %7.2f   ',0,0,0);
            fprintf(fid,'%3d  %3d  %7.2f   ',0,0,0);
        end    
        
        if nx <= 150 && nQC == 0
            [~,fval,time,status] = quadprogbb(2*(H-c*c'),f,Aineq,bineq,Aeq,beq,xlb,xub);
            clear functions
            fprintf(1,'fval = %.6f,  time = %6.2f\n',fval,time);
            fprintf(fid,'%13.6f %7.2f %7.2f %6d  ',fval,time,status.gap,status.nodes);
        else
            fprintf(fid,'%13.6f %7.2f %7.2f %6d  ',0,0,0,0);
        end
        
        if nx <= 20         
            [~,fval,time,info] = solve_qcqp_baron(H,f,c,Aineq,bineq,Aeq,beq,Q,q,r,xlb,xub,err);
            fprintf(fid,'%12.8f %7.2f %3d   ',fval,time,info.BaR_Iterations);            
            clear functions 
        else
            fprintf(fid,'%12.8f %7.2f %3d   ',0,0,0);
        end
        
        fprintf(fid,'\n');

    end
    fclose(fid);

end
end
end
catch error        
    fid1 = fopen('error_message.txt','wt+');
    fprintf(fid1,'Error information:\n  %s \n',error.message);
    fprintf(fid1,'Error in ''%s.m'' ',error.stack.name);
    fprintf(fid1,'(line %d)\n',error.stack.line);
    fprintf(fid1,'Located in ''%s'' \n',error.stack.file);
    fclose(fid1);    
%     !shutdown -s -t 600
    rethrow(error);
end
% !shutdown -s -t 300
% !shutdown -a
end