function average_results_table2()
% average results for talbe 2
clc;
err = 1.0e-6;
allqc = [0 1 3 5];                % number of quadratic constraints 
allnr = [1 2 3 5 8 10];         % number of negative eigenvalue

for inr = 3:6
    nr = allnr(inr);
for iqc = 1:1
    nQC = allqc(iqc);    
for iloop = 1:10
    nx = iloop*500;           % the number of variables
%     nLC = round(nx/5);       % the number of linear constraints      
    nLC = 0;
    
    filename = sprintf('results\\concave01qp_results_%d_%d_%d_%d.txt',nQC,nLC,nx,nr);
%     fprintf(1,'%s\n',filename);
    if  nx>1000 && mod(nx,500)~=0
        continue;
    end
%     fid = fopen(filename,'at+');
   
    
    alldata = load(filename);
    x = sum(alldata,1)/size(alldata,1);
%     size(x) 
%     continue
    i=1;
% 
%     fprintf(1,'%2d & ',x(i,2));   %nQC
%     fprintf(1,'%3d & ',x(i,3));   %nLC
    fprintf(1,'%4d & %2d & ',x(i,4),nr);   %nx,nr    
    % BB
    fprintf(1,'%10.4f & %7.2f & %3d & ',x(i,5),x(i,6),round(x(i,8))); % val,time,iter
%     fprintf(1,'%10.4f & ',x(i,12)); % val_adm
%     fprintf(1,'%2d & ',round(x(i,10))); % T_adm
    
    % cplex
    fprintf(1,'%10.4f & %.2f & %d & ',x(i,11),x(i,12)); % val,time
    
    % KKT-SDP
%     fprintf(1,'%10.4f & %7.2f & ',x(i,23),x(i,24)); % val,time
    
    fprintf(1,'\\\\ \n');

end
end
fprintf(1,'\\hline \n');
end