% function [x_opt,v_opt,gap,time,iter] = solve_qcp(filename,kk)
% load(filename);                                                                   
function [x_opt,v_opt,time,gap,iter,iter_nadm,time_nadm,v0,t0,numsol] = globalsol_qcqp_lr_mimo(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,err,kk)
% solving the following problem with ADMBB
% min  x'*H*x + f'*x - \sum_{i=1}^{nr} (c_i^T x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub.
% where
% H = \sum_{i=nr+1}^{n} (c_i*c_i^T), i=nr+1,...n,
%
% kk=1, restart NADM
%

%%
[nx,nr] = size(c);
if isempty(H)
    H = sparse(nx,nx);
end
H = (H+H')/2;

%% initial lower and upper bound for t=c'x
tl0 = zeros(nr,1);
tu0 = zeros(nr,1);

for i=1:nr
    [~,tl0(i)] = cplexqcp([], c(:,i),Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
    [~,tu0(i)] = cplexqcp([],-c(:,i),Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);    
end
tu0 = -tu0;
%
if nr == 1    
    rho = [-1 1];
elseif nr == 2
    [x1,x2] = ndgrid([-1,1],[-1 1]);
    rho = [x1(:),x2(:)]';
elseif nr == 3
    [x1,x2,x3] = ndgrid([-1,1],[-1 1],[-1 1]);
    rho = [x1(:),x2(:),x3(:)]';
elseif nr == 4
    [x1,x2,x3,x4] = ndgrid([-1,1],[-1 1],[-1 1],[-1 1]);
    rho = [x1(:),x2(:),x3(:),x4(:)]';
elseif nr == 5
    [x1,x2,x3,x4,x5] = ndgrid([-1,1],[-1 1],[-1 1],[-1 1],[-1 1]);
    rho = [x1(:),x2(:),x3(:),x4(:),x5(:)]';
else
    fprintf(2,'\nThe number of nr is greater than 5\n');
    rho = [-ones(nr,1),ones(nr,1)];
end

%%
MaxIter = 100000;
MaxTime = 3600;
iter_nadm = 0;
time_nadm = 0;
fprintf(1,'\n========= Solving by Branch and Bound =========\n');
fprintf(1,'Initial: tl0 = %.10f, tu0 = %.10f\n',[tl0,tu0]');
slo = NADM_initial(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
cplex_lr = cplex_LR_mimo(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,r(end));
%
tstart = tic;
nrho = size(rho,2);
x_all = zeros(nx,nrho);
v_all = zeros(nrho,1);
for ii = 1:nrho
    x0 = cplexqcp([], c*rho(:,ii),Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);   
    x1 = NADM(f,c,c'*x0,slo,err);    
    v1 = faux(x1,[],H,f,c);
    v_all(ii) = v1;
    x_all(:,ii) = x1;
end
v_opt = min(v_all);
v0 = v_opt;
t0 = toc(tstart);
x_opt = x_all(:,abs(v_all-v_opt)<1.0e-6);

clear x_all v_all;
fprintf(1,'Elapsed time is %.2f\n',toc(tstart));

% solve the relaxation at root nodes
[x,s,lb] = getbound_LR(cplex_lr,tl0,tu0,f,c);
prob.tlb = tl0;
prob.tub = tu0;
% prob.dist = prob.tub-prob.tlb;
t = c'*x;
prob.dist = s-t.^2;
prob.lb = lb;
prob.s = s;
prob.t = t;
v = x'*H*x + f'*x - (norm(t))^2;
if v < v_opt-1.0e-6
    v_opt = v;
    x_opt = x;
elseif abs(v-v_opt) <= 1.0e-6
    x_opt = [x_opt,x];
end

%%
gLB = prob.lb;
AllNodes = [];
iter = 0;
fprintf(1,'Iter = %3d, gLB = %12.8f, gUB = %12.8f, gap = %5.2f%%\n',...
    iter,gLB,v_opt,100*abs(v_opt-gLB)/(1.0e-10+abs(v_opt)));
subprob = cell(2,1);
while iter < MaxIter && toc(tstart) < MaxTime
    iter = iter+1;
    %  
    subprob{1} = prob;
    subprob{2} = prob;   
    [~,i_max] = max(prob.dist);
%     fprintf(1,'i_max = %d, dist = %.8f,  %.8f,  %.8f\n',i_max,prob.tub(i_max)-prob.tlb(i_max),prob.tlb(i_max),prob.tub(i_max));
    midpoint = (prob.tub(i_max)+prob.tlb(i_max))/2;
    if prob.s(i_max) <= (prob.tlb(i_max)+midpoint)*prob.t(i_max)-prob.tlb(i_max)*midpoint...
            || prob.s(i_max) <= (prob.tub(i_max)+midpoint)*prob.t(i_max)-prob.tub(i_max)*midpoint        
         midpoint = prob.t(i_max);
    end
    subprob{1}.tub(i_max) = midpoint;
    subprob{2}.tlb(i_max) = midpoint;
    
    for ii=1:2
        [x,s,lb] = getbound_LR(cplex_lr,subprob{ii}.tlb,subprob{ii}.tub,f,c);        
        if ~isempty(x)    
            t = c'*x;
            subprob{ii}.dist = s-t.^2;
            subprob{ii}.lb = lb;
            subprob{ii}.s = s;
            subprob{ii}.t = t;
            v = faux(x,[],H,f,c);            
            if kk == 1 && v < v_opt               
                [x1,~,~,~,time0] = NADM(f,c,c'*x,slo,err);
                iter_nadm = iter_nadm + 1;
                time_nadm = time_nadm + time0;
                v1 = faux(x1,[],H,f,c);                
                if v1 < v_opt-1.0e-6
                    fprintf(1,'Call NADM successfully!\n');
                    v_opt = v1;
                    x_opt = x1;
                elseif abs(v1-v_opt) <= 1.0e-6
                    x_opt = [x_opt,x1];
                end 
            end
            if v < v_opt-1.0e-6
                v_opt = v;
                x_opt = x;
            elseif abs(v-v_opt) <= 1.0e-6
                x_opt = [x_opt,x];
            end            
            %
            if sum(subprob{ii}.dist) > err
                AllNodes = [AllNodes,subprob{ii}];
            end
        end
    end  
%     fprintf(1,'lb1=%.8f, lb2=%.8f\n',subprob(1).lb,subprob(2).lb);
    %
    if ~isempty(AllNodes)
        ii = 0;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).lb >= v_opt-err
                AllNodes(ii) = [];
                ii = ii-1;
            end
        end
    end
    if isempty(AllNodes) 
        gLB = v_opt;
        break;
    else
        gLB = AllNodes(1).lb;
        index_LB = 1;
        ii = 1;
        while ii < length(AllNodes)
            ii = ii+1;
            if AllNodes(ii).lb < gLB
                gLB = AllNodes(ii).lb;
                index_LB = ii;
            end
        end
        prob = AllNodes(index_LB);
%         fprintf(1,'norm = %.8f, err = %.8f\n',norm(prob.tub-prob.tlb)^2/4,err);
        AllNodes(index_LB) = [];
    end
%     if mod(iter,10) == 0
        fprintf(1,'Iter = %3d, gLB = %12.8f, gUB = %12.8f, gap = %5.2f%%\n',...
            iter,gLB,v_opt,100*abs(v_opt-gLB)/(1.0e-10+abs(v_opt)));
%     end
end
% x_opt
numsol = size(x_opt,2);
x_opt = x_opt(:,1);
fprintf(1,'Iter = %3d, gLB = %12.8f, gUB = %12.8f, gap = %5.2f%%\n',...
    iter,gLB,v_opt,100*abs(v_opt-gLB)/(1.0e-10+abs(v_opt)));
gap = 100*abs(v_opt-gLB)/(1.0e-10+abs(v_opt));
time = toc(tstart);
end