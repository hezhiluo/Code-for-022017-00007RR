function test_clique()
% sovle the clique problem
%
clear
clc
% Add the Cplex path to Matlab search path. 
% It should be change in different server
% addpath('D:\Program Files\IBM\ILOG\CPLEX_Studio1263\cplex\matlab\x64_win64');
% 
nxall = [5 8 10 15 18 20 23 25 27];
nkall = [3 4  6  8  9 10 12 13 14];
for iloop = 1:9
    nx = nxall(iloop);   % number of vertex  
    nk = nkall(iloop);   % k
    jloop = 1;        
    fig_data_file = sprintf('data_clique\\fig_data_%d_%d_%d.mat',nx,nk,jloop);
    data_file = sprintf('data_clique\\data_%d_%d_%d.mat',nx,nk,jloop);
    
    %%
    fig_name = sprintf('%d',iloop);
    data2fig(fig_data_file,fig_name);    
    %%
    fprintf(1,'%4d  %3d  %3d  ',jloop,nx,nk);
            
    load(data_file);
    %% compare
    % initial t
    [~,tl0] = cplexqcp([], c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
    [~,tu0] = cplexqcp([],-c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
    tu0 = -tu0;
    fprintf(1,'\nInitial: tl0 = %.10f, tu0 = %.10f\n',tl0,tu0);
    
    %%
    [x,val_opt,time,iter]=solve_qcqp_gsa(H,f,c,Q,q,r,Aeq,beq,Aineq,bineq,xlb,xub,err);
    fval = (f'*x)-(c'*x)^2;  
    fprintf(1,'fval = %10.8f, time = %6.2f, iter = %d \n',fval,time,iter);
    fprintf(1,'x=\n');
    fprintf(1,'%d ',x(1:nx));
    fprintf(1,'\n');
        
end
end
