function [x,s,fval,time] = getbound_LR(cplex_lr,tlb,tub,f,c)
% Solve the linear relaxation of QCQP over [tlb,tub]
% min  x'*H*x + f'*x - \sum_{i=1}^{nr} s_i
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub,
%      s_i <= (tl(i)+tu(i))*(c_i^T x)-tl(i)*tu(i)
%      tlb(i) <= c_i^T x <= tub(i), i=1,...,nr.
%
tstart = tic;
[nx,nr] = size(c);
cplex = cplex_lr;
% cplex.DisplayFunc = [];
% cplex.Model.sense = 'minimize';
cplex.Model.A(end-3*nr+1:end-2*nr,1:nx) = -(c*diag(tlb+tub))';
cplex.Model.rhs(end-3*nr+1:end-2*nr) = -(tlb.*tub);
cplex.Model.rhs(end-2*nr+1:end) = [tub;-tlb];  
cplex.solve();
% cplex.writeBasis('myprob.bas');
% cplex.writeModel('11.lp');
if cplex.Solution.status ~= 1
    x = [];
    s = [];
    fval = inf;
    fprintf(2,'Solution.time = %.f,  ',cplex.Solution.time);
    fprintf(2,'Solution.status = %d: ',cplex.Solution.status);
    fprintf(2,'%s\n',cplex.Solution.statusstring);
else
    x = cplex.Solution.x(1:nx);
    s = cplex.Solution.x(nx+1:end);
    fval = cplex.Solution.objval;    
end
time = toc(tstart);
end