function [x_opt,t_opt,v_opt,iter,time] = NADM1(f,c,t0,slo,eps)
% successive linear optimization
%
% 
MaxIter = 100;
MaxTime = 1800;
x_opt = [];
t_opt = [];
v_opt = [];
% cplex = Cplex();
% cplex.DisplayFunc = [];
% cplex.Param = slo.Param;
% cplex.Model = slo.Model;
cplex = slo;

%%
t = t0;
iter = 0;
dist = inf;
tstart = tic;
%% 
cplex.addRows(t,c',inf);
while iter<MaxIter && toc(tstart)<MaxTime
    iter = iter+1;
    cplex.Model.obj = f-(2*t)*c;
    cplex.Model.lhs(end) = t;
    cplex.solve();
    if cplex.Solution.status ~= 1
        fprintf(2,'\nExist in NADM1:');
        fprintf(2,'time = %.2f,  ',cplex.Solution.time);
        fprintf(2,'status = %d: ',cplex.Solution.status);
        fprintf(2,'%s\n',cplex.Solution.statusstring);
    end
    x = cplex.Solution.x;
    tp = t;
    t = c'*x;
    fprintf(1,'NADM1: iter = %3d, t-tp = %.6f\n',iter,abs(t-tp));     
    if norm(t-tp) < dist
        dist = norm(t-tp);
        x_opt = x;
        t_opt = c'*x_opt;
    end
    if abs(t-tp)<sqrt(eps)
        x_opt = x;
        t_opt = c'*x_opt;
        v_opt = cplex.Solution.objval;
        break;
    end    
end
cplex.delRows(size(cplex.Model.A,1));
time = toc(tstart);
end