function test_01qp()
% solving the following 0-1 problem
% min  f'*x - \sum_{i=1}^{nr} (c_i'*x)^2
% s.t. x \in {0,1}
%
clear
% clc
% Add the Cplex path to Matlab search path if necessary. 
% It should be change in different server
% addpath('D:\Program Files\IBM\ILOG\CPLEX_Studio1263\cplex\matlab\x64_win64');
% rand('state',10);
% randn('state',10);
% rng(0,'twister');
err = 1.0e-4;
nQC = 0;                % the number of quadratic constraints
nLC = 0;                % the number of linear constraints      
allnr = [1 2 3 5 8 10]; % the number of negative eigenvalues
nex = 5;                % the number of the numerical examples
try    
for ir = 3:6
    nr = allnr(ir);     % the number of negative eigenvalues
for iloop = 1:10
    nx = iloop*500;     % the number of variables    
    % save the compution results
    filename = sprintf('results\\concave01qp_results_%d_%d_%d_%d.txt',nQC,nLC,nx,nr);
    fid = fopen(filename,'at+');
%     fid = 1;
    jloop = 0;
    while jloop < nex
        jloop = jloop+1;  
        % generate the data
        x0 = rand(nx,1);   %[0,1]
        w = 2*rand(nx,3)-1;  % [-1,1]
        W = cell(3,1);
        for i3=1:3
            W{i3} = eye(nx)-2*w(:,i3)*w(:,i3)'/norm(w(:,i3))^2;
        end
        P = W{1}*W{2}*W{3};
        d = 1*rand(nx,1);      % U[0,1]
        index = randperm(nx);        
        index = index(1:nr);    % nr is the number of negative eigenvalue
        d(index) = -d(index);
        d(d>=0) = 0;        
        H0 = P*diag(d)*P';   % negative definite
        H0 = (H0+H0')/2;
        [V,D] = eig(H0);                
        H = [];        
        f = 2*rand(nx,1)-1;   % U[-1,1]        
        c = V(:,1:nr)*sqrt(-D(1:nr,1:nr));      
        
        % constraints
        Q = cell(1,nQC);
        q = zeros(nx,nQC);
        r = zeros(1,nQC);
        W = cell(3,1);
        for iQC = 1:nQC
            w = 2*rand(nx,3)-1;  % [-1,1]
            for i3=1:3
                W{i3} = eye(nx)-2*w(:,i3)*w(:,i3)'/norm(w(:,i3))^2;
            end
            P = W{1}*W{2}*W{3};
            Q{iQC} = P*diag(5*rand(nx,1))*P';   % positive definite
            Q{iQC} = (Q{iQC}+Q{iQC}')/2;
            q(:,iQC) = 10*rand(nx,1);   % [0,10]
            r(iQC) = max(diag(x0'*Q{iQC}*x0)+x0'*q(:,iQC))+1*rand;
        end
        % Ax<=b
        Aineq = [];
        bineq = [];
        Aeq = [];
        beq = [];
        xlb = zeros(nx,1);
        xub =  ones(nx,1);     

        %        
        fprintf(1,'nr=%d, iloop=%d, jloop=%d\n',nr,iloop,jloop);
      
       %% compare dirrerent methods       
        fprintf(fid,'%3d %3d %3d %3d   ',jloop,nQC,nLC,nx); %1
        
        [x_opt,v_opt,time,gap,iter,nadm,v0] = globalsol_qcqp_lr(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,err,1);
        clear functions        
        fprintf(fid,'%12.8f %7.2f %7.2f %3d %3d %12.8f   ',v_opt,time,gap,iter,nadm,v0); % 5
        
        [x,fval,time,gap,iter] = cplex_01qp(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
        clear functions        
        fprintf(fid,'%12.8f %7.2f %7.2f %3d   ',fval,time,gap,iter);      %11  
        
%         [x,fval,time,status] = quadprogbb((-2*c)*c',f,Aineq,bineq,Aeq,beq,xlb,xub);
%         clear functions
%         fprintf(fid,'%12.6f %7.2f %7.2f %6d  ',fval,time,status.gap,status.nodes);
%         
        fprintf(fid,'\n');

    end
    fclose(fid);
%     pause(600);

end
end
catch error
%     !shutdown -s -t 600    
    rethrow(error);
end
% !shutdown -s -t 300
% !shutdown -a
end