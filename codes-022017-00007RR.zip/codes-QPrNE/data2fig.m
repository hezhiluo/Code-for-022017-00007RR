function data2fig(filename,figname)
load(filename);
nx = size(index,1);
figsize = [8,8];
fig = figure('PaperSize',figsize);
step = 2*pi/nx;
r = 2;
r1 = 2.2;
t = 0.5*pi:step:2.5*pi;

x = r*cos(t);
y = r*sin(t);
x1 = r1*cos(t);
y1 = r1*sin(t);
% v_set
for ii=1:nx
    if nnz(v_set==ii)~=0
        plot(x(ii),y(ii),'.b','markersize',18);
    else
         plot(x(ii),y(ii),'.b');
    end
    dotname = sprintf('%d',ii);
    text(x1(ii),y1(ii),dotname);
    hold on;
end

for jj=1:nx
    for ii=jj+1:nx
        if index(ii,jj)==1
            if nnz(v_set==ii)~=0 && nnz(v_set==jj)~=0
                plot([x(ii) x(jj)],[y(ii),y(jj)],'-b','linewidth',1.5);
                hold on;
            else
                plot([x(ii) x(jj)],[y(ii),y(jj)],'-b');
                hold on;
            end
        end
    end
end
xlim([-3,3]);
ylim([-3,3]);
figname = ['\itG_{\rm{',figname,'}}'];
xlabel(figname,'fontsize',14,'Interpreter','Tex');
hold off

figfilename = sprintf('data_clique\\fig_%d_%d.eps',nx,jloop);
print(fig, '-depsc',figfilename);

end