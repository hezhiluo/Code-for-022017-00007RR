function average_results_table8()
% average_results_mimo
clc;
err = 1.0e-6;
allqc = [0 1 3 5];   % number of quadratic constraints 
allnr = [1 2 3 4 5 8 10];            % number of negative eigenvalue

for ii=1:2
    filename = sprintf('results\\mimo_results_s%d.txt',ii);
%     fprintf(1,'%s\n',filename);
%     if  mod(nx,500)~=0  && nx>1000
%         continue;
%     end
    
%     fid = fopen(filename,'at+');
    
    alldata = load(filename); 
    
%     size(alldata)
for iii=0:3
    x = alldata(iii*10+1:iii*10+10,:);
%     size(x,1)
    x = sum(x,1)/size(x,1);
%     size(x)
    i = 1;
% 
    fprintf(1,'%2d & ',x(i,2)-1);   % nQC
    fprintf(1,'%2d & ',x(i,3));     % nx 
%     fprintf(1,'(%d,%d) & ',x(i,3)/2,x(i,3)/2);     % nx 
    fprintf(1,'%2d & ',x(i,4));     % nr  
    % BB
    fprintf(1,'%10.4f & %7.2f & ',x(i,5),x(i,6)); % val,time    
    fprintf(1,'%4d & ',round(x(i,8))); % iter  
%     fprintf(1,'%10.4f(%d) & %7.2f & %4d & ',x(i,5),nnz(index),x(i,6),round(x(i,8))); % val,time,iter    
%     fprintf(1,'%10.4f & ',x(i,11)); % val_adm
%     fprintf(1,'%2d & ',round(x(i,9))); % T_adm
    
    % gsa
%     fprintf(1,'%10.4f & %7.2f & %d & ',x(i,13),x(i,13),round(x(i,15))); % val,time,iter
%     fprintf(1,'%3d & ',round(x(i,21))); % T_lsa
%     fprintf(1,'%3d & %7.2f & ',round(x(i,16)),x(i,18)); % iter_adm,T_adm
    
    % KKT-SDP
%     fprintf(1,'%10.4f & %7.2f & ',x(i,22),x(i,23)); % val,time
%     fprintf(1,'%10.4f(%d) & %7.2f & ',x(i,22),nnz(index1),x(i,23)); % val,time
    
    % BARON
    fprintf(1,'%10.4f & %7.2f & ',x(i,26),x(i,27)); % val,time
%     fprintf(1,'%3d & ',x(i,28)); % iter

    fprintf(1,'\\\\ \n');

end
fprintf(1,'\\hline \n');
end