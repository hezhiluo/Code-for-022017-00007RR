function fcon = nlcon(x,Q,q)
nQC = size(Q,2);
% fcon = zeros(nQC);
for i = 1:nQC
    fcon(i) = x'*Q{i}*x+q(:,i)'*x;
end

end