function cplex = NADM_initial(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub)
%
%
try    
    %
    cplex = Cplex('slo_initial');
    cplex.DisplayFunc = [];
    cplex.Param.timelimit.Cur = 600;
    cplex.Param.emphasis.memory.Cur = 0;            % reduce use of memory;
    cplex.Model.sense = 'minimize';
    % lower and upper bound constraints
    cplex.addCols(f,[],xlb,xub);
    for iQC = 1:size(Q,2);       
        cplex.addQCs(q(:,iQC),Q{iQC},'L',r(iQC));
    end
    if ~isempty(Aeq) % Aeq*x = beq
        cplex.addRows(beq,Aeq,beq);
    end
    if ~isempty(Aineq) % Aineq*x <= bineq
        cplex.addRows(-inf*ones(size(bineq)),Aineq,bineq);    
    end
    if ~isempty(H)
        cplex.Model.Q = H+H';
    end
%     cplex.writeModel('SLO_common.lp');
%     fprintf(1,'The size of the linear constraints:');
%     fprintf(1,'    %d * %d\n',size(cplex.Model.A,1),size(cplex.Model.A,2));
%     fprintf(1,'The size of the quadratic constraints:');
%     fprintf(1,' %d\n',size(cplex.Model.qc,1));    
catch err
    rethrow(err);
end
end