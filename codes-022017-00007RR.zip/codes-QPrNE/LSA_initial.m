function cplex = LSA_initial(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub)
%
%
nx = length(c);
try    
    dim = nx+2; % x,s,t
    if ~isempty(H)
        HH = [H sparse(nx,2);
            sparse(2,dim)];
    else
        HH = [];
    end
    yf = [f;-1;0];
    if ~isempty(Aineq)
        yAineq = [Aineq, zeros(size(Aineq,1),2);
            zeros(1,nx), 1,0]; % s <= (l+u)*t-l*u
        ybineq = [bineq;0];
    else
        yAineq = [zeros(1,nx), 1,0]; % s <= (l+u)*t-l*u
        ybineq = 0;
    end
    if ~isempty(Aeq)
        yAeq = [Aeq sparse(size(Aeq,1),2);
            c',0,-1];  % c'*x-t=0
        ybeq = [beq;0];
    else
        yAeq = [c',0,-1];  % c'*x-t=0
        ybeq = 0;
    end
    ylb = [xlb;  0;-inf]; % x,s,t
    yub = [xub;inf; inf]; % x,s,t
    %
    cplex = Cplex('lsa_initial');
    cplex.DisplayFunc = [];
    cplex.Model.sense = 'minimize';
    % lower and upper bound constraints
    cplex.addCols(yf,[],ylb,yub);  
    cplex.addRows(ybeq,yAeq,ybeq);
    cplex.addRows(-inf*ones(size(ybineq)),yAineq,ybineq);
    for iQC = 1:size(Q,2)
        cplex.addQCs([q(:,iQC);0;0],[Q{iQC},sparse(nx,2);sparse(2,dim)],'L',r(iQC));
    end
    % t^2 <= s
%     cplex.addQCs(sparse(dim-1,1,-1,dim,1),sparse(dim,dim,1,dim,dim),'L',0.0);
    if ~isempty(HH)
        cplex.Model.Q = HH+HH';
    end
%     cplex.writeModel('LSA_common.lp');
%     fprintf(1,'The size of the linear constraints:');
%     fprintf(1,'    %d * %d\n',size(cplex.Model.A,1),size(cplex.Model.A,2));
%     fprintf(1,'The size of the quadratic constraints:');
%     fprintf(1,' %d\n',size(cplex.Model.qc,1));
catch err
    rethrow(err);    
end
end