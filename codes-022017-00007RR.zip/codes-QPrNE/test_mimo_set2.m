function test_mimo_set2()
% max  t^H A t
% s.t. t^H Q t <= 1, i=1,...,m
%      t^H t<= P_{s,max}
% where A,Q is Hermitian Complex Matrix
% First convert it to qcqp in real fields
% max  x'*[Ar -Ai; Ai Ar]*x
% s.t. x'*[Qr -Qi; Qi Qr]*x <= 1, i=1,...,m,
%      x'*[I 0; 0 I]*x <= P_{s,max}
% where x=[tr;ti];
% Then solving the following general qcqp
% min  x'*H*x+f'*x-\sum_{i=1}^{nr} (c_i'*x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub.
% refer to "An eigenvalue decomposition based branch-and-bound
% algorithm for nonconvex quadratic programming
% problems with convex quadratic constraints"
%
clear
clc
% addpath('D:\Program Files\IBM\ILOG\CPLEX_Studio1263\cplex\matlab\x64_win64');
% rand('state',10);
% randn('state',10);
% rng(0,'twister');
err = 1.0e-6;
% allqc = [0 1 3 5];          % number of quadratic constraints
% allnr = [1 2 3 4 5 6 8 10];   % number of negative eigenvalue
nex = 10;        % the number of the numerical examples

try
for ii = 1:2    % scenerio
for ik = 1:4
    nK = ik*10; % K
    filename = sprintf('results\\mimo_results_s%d10.txt',ii);
    fid = fopen(filename,'at+');
%     fid=1;

    jloop = 0;
    while jloop < nex
        jloop = jloop+1;
        % generate the data
        if ii==1
            [A0,Q0,r0] = generate_mimo_s1(10,10,nK);
        elseif ii==2
            [A0,Q0,r0] = generate_mimo_s2(10,10,nK);
        else
            return;
        end 
        nx = 2*size(A0,1);
        nQC = length(r0);
        
        % objective
        H0 = -[real(A0) -imag(A0);imag(A0) real(A0)]; % max -> min        
        % decomposition
        H0 = (H0+H0')/2;
        [V,D] = eig(H0);
%         index = diag(D) >= 1.0e-6;
        nr = nnz(diag(D) <= -1.0e-6);
%         H = V(:,index)*D(index,index)*V(:,index)';  % positive definite
        H = [];
        c = V(:,1:nr)*sqrt(-D(1:nr,1:nr));
        f = zeros(nx,1);
        
        % quadratic constraints
        Q = cell(1,nQC);
        q = zeros(nx,nQC);
        r = r0;
        for iQC = 1:nQC
            Q{iQC} = [real(Q0{iQC}) -imag(Q0{iQC});imag(Q0{iQC}) real(Q0{iQC})];
            Q{iQC} = (Q{iQC}+Q{iQC}')/2;
            q(:,iQC) = zeros(nx,1);
        end
        % Ax<=b
        Aineq = [];
        bineq = [];
        Aeq = [];
        beq = [];
        xlb = -inf*ones(nx,1);
        xub =  inf*ones(nx,1);

        fprintf(1,'nQC = %d, nx = %d, nr = %d, jloop = %d\n',nQC,nx,nr,jloop);

        %%
        
        fprintf(fid,'%3d  %3d  %3d  %3d  ',jloop,nQC,nx,nr);
        if nx <= 4000
            [x,v_opt,time,gap,iter,iter_nadm,time_nadm,v0,t0] =...
                globalsol_qcqp_lr_mimo(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub,err,1);
            fprintf(1,'iter = %3d ,fval = %.6f,  time = %6.2f\n',iter,v_opt,time);
            fprintf(fid,'%12.8f %7.2f %7.2f %3d   ',v_opt,time,gap,iter);
            fprintf(fid,'%3d  %7.2f   %12.8f %7.2f   ',iter_nadm,time_nadm,v0,t0);
            clear functions
        else
            fprintf(fid,'%12.8f %7.2f %7.2f %3d   ',0,0,0,0);
            fprintf(fid,'%3d  %7.2f   %12.8f %7.2f   ',0,0,0,0);
        end
        
        if nr == 1
            [~,fval,time,iter,iter_nadm,iter_nadm1,time_nadm,iter_lsa,iter_lsa1,time_lsa]...
                = solve_qcqp_gsa(H,f,c,Q,q,r,Aeq,beq,Aineq,bineq,xlb,xub,err);
            fprintf(fid,'%12.8f %7.2f %3d   ',fval,time,iter);
            fprintf(fid,'%3d  %3d  %7.2f   ',iter_nadm,iter_nadm1,time_nadm);
            fprintf(fid,'%3d  %3d  %7.2f   ',iter_lsa,iter_lsa1,time_lsa);
            clear functions
        else
            fprintf(fid,'%12.8f %7.2f %3d   ',0,0,0);
            fprintf(fid,'%3d  %3d  %7.2f   ',0,0,0);
            fprintf(fid,'%3d  %3d  %7.2f   ',0,0,0);
        end
        
        if nx <= 200 && nQC == 0
            [~,fval,time,status] = quadprogbb(2*(H-c*c'),f,Aineq,bineq,Aeq,beq,xlb,xub);
            clear functions
            fprintf(1,'fval = %.6f,  time = %6.2f\n',fval,time);
            fprintf(fid,'%13.6f %7.2f %7.2f %6d  ',fval,time,status.gap,status.nodes);
        else
            fprintf(fid,'%13.6f %7.2f %7.2f %6d  ',0,0,0,0);
        end
        
        if nx <= 25   
                       
            [~,fval,time,info] = solve_qcqp_baron(H,f,c,Aineq,bineq,Aeq,beq,Q,q,r,xlb,xub,err);
            fprintf(fid,'%12.8f %7.2f %3d   ',fval,time,info.BaR_Iterations);
            clear functions
        else
            fprintf(fid,'%12.8f %7.2f %3d   ',0,0,0);
        end
        
        fprintf(fid,'\n');       
    end
    fclose(fid);

end  
end
catch error
    fid1 = fopen('error_message.txt','wt+');
    fprintf(fid1,'Error information:\n  %s \n',error.message);
    fprintf(fid1,'Error in ''%s.m'' ',error.stack.name);
    fprintf(fid1,'(line %d)\n',error.stack.line);
    fprintf(fid1,'Located in ''%s'' \n',error.stack.file);
    fclose(fid1);
%     !shutdown -s -t 600
    rethrow(error);
end
% !shutdown -s -t 300
% !shutdown -a
end