% function [x,fval,time,iter,f1,t1] = solve_qcqp_gsa(filename)
% load(filename);
function [x_opt,v_opt,time,iter,iter_nadm,iter_nadm1,time_nadm,iter_lsa,iter_lsa1,time_lsa] = solve_qcqp_gsa(H,f,c,Q,q,r,Aeq,beq,Aineq,bineq,xlb,xub,err)
% solving the following problem by GSA (for 1 negative eigenvalue only)
% min  x'*H*x+f'*x-(c'*x)^2
% s.t. x'*Q{i}*x + q{i}'*x <= r(i), i=1,...,m,
%      Aineq*x <= bineq,
%      Aeq*x = beq,
%      xlb <= x <= xub.
%
MaxIter = 1000;  % maximal iteration
MaxTime = 3600;  % maximal solving time 
nx = length(c);  % number of varialbes
tol = 2*sqrt(err);

%% initial lower and upper bound for t=c'x
[~,tl0] = cplexqcp([], c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
[~,tu0] = cplexqcp([],-c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
tu0 = -tu0;

%%
fprintf(1,'\n========= Solving by Global Search Algorithm =========\n');
fprintf(1,'Initial: tl0 = %.10f, tu0 = %.10f\n',tl0,tu0);
tstart = tic;
iter_nadm = 0;
iter_nadm1 = 0;
iter_lsa = 0;
iter_lsa1 = 0;
time_nadm = 0;
time_lsa = 0;
slo = NADM_initial(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
lsa = LSA_initial(H,f,c,Aineq,bineq,Aeq,beq,q,Q,r,xlb,xub);
%
[xl,~,~,iter0,time0] = NADM(f,c,tl0,slo,err);
time_nadm = time_nadm + time0;
iter_nadm = iter_nadm + 1;
iter_nadm1 = iter_nadm1+iter0;
%
[xu,~,~,iter0,time0] = NADM(f,c,tu0,slo,err);
time_nadm = time_nadm + time0;
iter_nadm = iter_nadm + 1;
iter_nadm1 = iter_nadm1+iter0;
%
v1 = faux(xl,[],H,f,c);
v2 = faux(xu,[],H,f,c);
if v1<=v2
    v_opt = v1;    
    x_opt = xl;
else
    v_opt = v2;    
    x_opt = xu;
end
fprintf(1,'Elapsed time is %.2f\n',toc(tstart));

%%
iter = 1;
tl = c'*xl;
tu = c'*xu;
dist = tu-tl;
while dist > tol && iter < MaxIter && toc(tstart) < MaxTime    
    fprintf(1,'Iter = %2d, dist = %.10f, tl = %.10f, tu = %.10f\n',iter,dist,tl,tu);
    iter = iter+1; 
    %             
    delta_l = (tu-tl)/2;
    delta_u = delta_l;    
    [~,vl] = LSA0(H,f,c,tl, delta_l,lsa);
    [~,vu] = LSA0(H,f,c,tu,-delta_u,lsa);
    %
    if vl >= v_opt-eps          
        tl = tl+delta_l;
        fprintf(1,'Ldist = %.10f, tl = %.10f, tu = %.10f\n',tu-tl,tl,tu);
        [x1,tl,~,iter0,time0] = NADM1(f,c,tl,slo,err);
        time_nadm = time_nadm + time0;
        iter_nadm = iter_nadm + 1;
        iter_nadm1 = iter_nadm1+iter0;
        v1 = faux(x1,[],H,f,c);
        if v1<v_opt
            v_opt = v1;
            x_opt = x1;
        end  
        fprintf(1,'Ldist = %.10f, tl = %.10f, tu = %.10f\n',tu-tl,tl,tu);
    elseif vu >= v_opt-eps       
        tu = tu-delta_u;
        fprintf(1,'Rdist = %.10f, tl = %.10f, tu = %.10f\n',tu-tl,tl,tu);
        [x2,tu,~,iter0,time0] = NADM2(f,c,tu,slo,err);         
        time_nadm = time_nadm + time0;
        iter_nadm = iter_nadm + 1;
        iter_nadm1 = iter_nadm1+iter0;
        v2 = faux(x2,[],H,f,c);
        if v2<v_opt
            v_opt = v2;
            x_opt = x2;
        end      
        fprintf(1,'Rdist = %.10f, tl = %.10f, tu = %.10f\n',tu-tl,tl,tu);
    else
        %
        delta_l = (tu-tl)/4;
        delta_u = delta_l;
        [delta,x_opt,~,v_opt,~,iter1,time1] = LSA(H,f,c,tl,delta_l,v_opt,x_opt,lsa,err);
        tl = tl+delta;
        iter_lsa = iter_lsa + 1;
        time_lsa = time_lsa + time1;
        iter_lsa1 = iter_lsa1 + iter1;
        if tu-tl <= tol
            break;
        end
        %
        [delta,x_opt,~,v_opt,~,iter1,time1] = LSA(H,f,c,tu,-delta_u,v_opt,x_opt,lsa,err);
        tu = tu+delta; 
        iter_lsa = iter_lsa + 1;
        iter_lsa1 = iter_lsa1 + iter1;
        time_lsa = time_lsa + time1;
        if tu-tl <= tol
            break;
        end
        %
        [x1,tl,~,iter0,time0] = NADM1(f,c,tl,slo,err);
        time_nadm = time_nadm + time0;
        iter_nadm = iter_nadm + 1;
        iter_nadm1 = iter_nadm1+iter0;
        v1 = faux(x1,[],H,f,c);
        if v1<v_opt
            v_opt = v1;
            x_opt = x1;
        end        
        if tu-tl <= tol
            break;
        end
        %
        [x2,tu,~,iter0,time0] = NADM2(f,c,tu,slo,err);
        time_nadm = time_nadm + time0;
        iter_nadm = iter_nadm + 1;
        iter_nadm1 = iter_nadm1+iter0;
        v2 = faux(x2,[],H,f,c);
        if v2<v_opt
            v_opt = v2;
            x_opt = x2;
        end        
        if tu-tl <= tol
            break;
        end
    end
    dist = tu-tl;
end
fprintf(1,'Iter = %2d, dist = %.10f, tl = %.10f, tu = %.10f\n',iter,dist,tl,tu);

%%
if iter > MaxIter || toc(tstart) > MaxTime
    fprintf(2,'Solving failed!!\n');    
    fprintf(2,'Exceeding the maximum solving time!!\n');
    fprintf(2,'Or Exceeding the maximum iteration!!\n');
    time = toc(tstart);
    return;
end

%%
dist = tu-tl;
if dist <= 0
    fprintf(1,'Final: tl = %.10f, tu = %.10f, dist = %.10f\n',tl,tu,dist);
elseif dist <= tol
    cplex = lsa;
    cplex.Model.lb(end) = tl;
    cplex.Model.ub(end) = tu;
    cplex.Model.A(end,end) = -(tl+tu);
    cplex.Model.rhs(end) = -(tl*tu);
    cplex.solve();
    if cplex.Solution.status ~= 1
        fprintf(2,'\nExist in LSA:\n');
        fprintf(2,'\nSolution.time = %.f,  ',cplex.Solution.time);
        fprintf(2,'Solution.status = %d: ',cplex.Solution.status);
        fprintf(2,'%s\n',cplex.Solution.statusstring);
    end
    x = cplex.Solution.x(1:nx);    
    v = faux(x,[],H,f,c);
    if v<v_opt
        v_opt = v;
        x_opt = x;
    end
else
    fprintf(1,'There is something wrong! dist = %.10f\n',dist);
    time = toc(tstart);
    return;
end
time = toc(tstart);
fprintf(1,'Iter = %2d, fval = %.6f, time = %6.2f\n',iter,v_opt,time);
end