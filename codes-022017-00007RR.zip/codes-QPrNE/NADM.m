function [x_opt,t_opt,v_opt,iter,time] = NADM(f,c,t0,slo,err)
% successive linear optimization
%
% 
MaxIter = 100;
MaxTime = 1800;
x_opt = [];
t_opt = [];
v_opt = [];
% cplex = Cplex();
% cplex.DisplayFunc = [];
% cplex.Param = slo.Param;
% cplex.Model = slo.Model;
cplex = slo;

%%
t = t0;
iter = 0;
dist = inf;
tstart = tic;
%%    
while iter<MaxIter && toc(tstart)<MaxTime
    iter = iter+1;
    cplex.Model.obj = f-2*(c*t);            
    cplex.solve();
    if cplex.Solution.status ~= 1
        fprintf(2,'\nExist in NADM:\n');
        fprintf(2,'time = %.2f,  ',cplex.Solution.time);
        fprintf(2,'status = %d: ',cplex.Solution.status);
        fprintf(2,'%s\n',cplex.Solution.statusstring);
    end
    x = cplex.Solution.x;
    tp = t;
    t = c'*x;
    fprintf(1,'NADM: iter = %3d, t-tp = %.6f\n',iter,norm(t-tp));        
    if norm(t-tp) < dist
        dist = norm(t-tp);
        x_opt = x;
        t_opt = c'*x_opt;
    end
    if norm(t-tp)<sqrt(err)
        x_opt = x;
        t_opt = c'*x_opt;
        v_opt = cplex.Solution.objval;
        break;
    end
end
time = toc(tstart);
end