function [x_opt,t_opt,v_opt,time] = gfun(f,c,t0,slco)
%
%
% 
x_opt = [];
t_opt = [];
v_opt = [];
% cplex = Cplex();
% cplex.DisplayFunc = [];
% cplex.Param = slco.Param;
% cplex.Model = slco.Model;
cplex = slco;

%%
tstart = tic;
%%    
cplex.Model.obj = f-(2*t0)*c;
cplex.solve();
if cplex.Solution.status ~= 1
    fprintf(2,'\nExist in gfun:\n');
    fprintf(2,'time = %.2f,  ',cplex.Solution.time);
    fprintf(2,'status = %d: ',cplex.Solution.status);
    fprintf(2,'%s\n',cplex.Solution.statusstring);
else
    x_opt = cplex.Solution.x;
    t_opt = c'*x_opt;
    v_opt = cplex.Solution.objval;
end
time = toc(tstart);
end